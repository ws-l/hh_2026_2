#pip install fastapi[standard]
#fastapi dev 파일.py
from fastapi import FastAPI
import pandas as pd
import numpy as np

app = FastAPI()

df = pd.read_csv("data.csv")
df.drop(columns = "Pass.Fail", inplace=True)

@app.get("/data")
def date_gen(row: int = 50):
    x = df.sample(row)
    return  x.to_dict(orient="records")
